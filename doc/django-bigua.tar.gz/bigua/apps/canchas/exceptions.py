class CanchaNoDisponibleError(Exception):
    pass

class ReservaSuperpuestaError(Exception):
    pass
