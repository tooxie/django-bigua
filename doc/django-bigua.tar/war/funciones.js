function validate(idQueLlama, element) {
    numeroCaracteres = element.value.length;
    if( (numeroCaracteres%10) == 0 & numeroCaracteres>0){
        guardarTmp( idQueLlama, element);
    }
}                         

function guardarTmp(idQueLlama, element) {     
    var url = "SrvltAjx?accion=guardardatos&campo="+idQueLlama+"&dato=" + encodeURIComponent(element.value);
    if (typeof XMLHttpRequest != "undefined") { 
        req = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        req = new ActiveXObject("Microsoft.XMLHTTP");
    }
    req.open("GET", url, true);               
    req.onreadystatechange = callback;               
    req.send(null);
}

function callback() {                              
}

function guardarUltimaPagina(ppagina) { 
    var url = "SrvltAjx?accion=guardarpag&pagina="+ppagina;
    if (typeof XMLHttpRequest != "undefined") {                  
        req = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        req = new ActiveXObject("Microsoft.XMLHTTP");
    }                           
    req.open("GET", url, true);               
    req.onreadystatechange = callback;               
    req.send(null);
}
